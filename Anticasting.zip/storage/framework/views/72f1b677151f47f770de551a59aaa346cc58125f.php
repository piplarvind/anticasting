
<div class="breadcrumbs">
    <div class="page-header d-flex align-items-center" style="background-image: url('<?php echo e(asset('assets/website/images/page-banner.png')); ?>');">
      <div class="container position-relative">
        <div class="row d-flex justify-content-center">
          <div class="col-lg-6 text-center">
            <h2>Dashboard</h2>
            
          </div>
        </div>
      </div>
    </div>
    <nav>
      <div class="container">
        <ol>
          <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
          <li>Dashboard</li>
        </ol>
      </div>
    </nav>
  </div>
<h3>Dashboard</h3>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting\resources\views/dashboard.blade.php ENDPATH**/ ?>