<?php
    $action = route('users.submitProfile.store');
    $method = '';
    $submitButton = 'Submit';
    
    if (request()->is('*/submitProfile/edit/*')) {
        $submitButton = 'Update';
        // $method = 'PUT';
        //$action = route('users.submitProfile.update', $userProfile->id);
    }
?>


<?php $__env->startSection('header'); ?>
    <style>
        #contact_select {
            background: #FFF;
            color: #aaa;
        }

        #contact label {
            color: #000;
            font-size: 17px;
            font-family: "Roboto", Helvetica, Arial, sans-serif;
            font-weight: 500;
        }

        .card-size {
            margin-top: 275px;
        }

        .msgs li {
            list-style-type: none;
            padding: 2px;
            border-bottom: 1px dotted #ccc;
        }

        .show-image {
            margin-right: 200px;
            cursor: pointer;
            font-size: 22px;
            color: blue;
        }

        .card-header {
            background-color: #fff !important;
        }

        .submit-header {
            align-items: center;
            background: #FFF;
            justify-content: space-between;
            padding: 0;
        }

        .title {
            align-items: center;
            text-align: center;
            padding-top: 8px;
        }

        .text-countryCode {
            max-width: 55px;
            text-align: center;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/auth/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/submit-profile.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/image-gallery.css')); ?>" />

    <script src="<?php echo e(asset('assets/auth/jquery-3.6.0.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/auth/toastr.min.css')); ?>">
    <script src="<?php echo e(asset('assets/auth/toastr.min.js')); ?>"></script>
    
    
    
    
    
    
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="contact" class="contact">
        <script>
            <?php if(Session::has('message')): ?>
                toastr.success("<?php echo e(Session::get('message')); ?>");
            <?php elseif(Session::has('error')): ?>
                toastr.error("<?php echo e(Session::get('error')); ?>");
            <?php elseif(Session::has('success')): ?>
                toastr.success("<?php echo e(Session::get('success')); ?>");
            <?php endif; ?>
        </script>
        <div class="container aos-init aos-animate" data-aos="fade-up">
            <div class="row gy-4">

                <div class="col-md-3">
                    <?php echo $__env->make('submit-profile.left-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>

                <div class="col-lg-5">
                    <div class="card">
                        <div class="card-header">
                            <div class="submit-header" <?php if(!Request::is('*/edit/*')): ?> style="display: flex;" <?php endif; ?>>
                                <div class="title">
                                    <h3 class="text-center" class="m-5" style="color: #bb99ff;">ACTOR PROFILE</h3>
                                </div>
                                <?php if(isset($userProfile) && $userProfile->id != null): ?>
                                    <div class="edit-btn">

                                        <a href="<?php echo e(route('users.submitProfile.edit', $userProfile->id)); ?>"
                                            style="margin-left:12px;" class="text-right btn btn-secondary">
                                            <span class="fa fa-pencil" aria-hidden="true"></span>
                                            Edit
                                        </a>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="card-body">
                            <form method="post" action="<?php echo e($action); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if($method == 'PUT'): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="exampleInputName"><b>Firstname</b>&nbsp;<span
                                                    style="color:red;">*</span></label>
                                            <input type="text" name="first_name" class="form-control"
                                                id="exampleInputName" aria-describedby="emailHelp"
                                                placeholder="Enter firstname"
                                                value="<?php echo e(old('first_name', isset($userInfo->first_name) ? $userInfo->first_name : '')); ?>">
                                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="last_name"><b>Lastname</b>&nbsp;<span
                                                    style="color:red;">*</span></label>
                                            <input type="text" name="last_name" class="form-control"
                                                id="exampleInputName" aria-describedby="last_name"
                                                value="<?php echo e(old('last_name', isset($userInfo->last_name) ? $userInfo->last_name : '')); ?>"
                                                placeholder="Enter Lastname">
                                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label text-secondary text-gradient" id="contact"><b>Contact
                                            </b><span style="color:red;">*</span>
                                        </label>
                                        <div class="input-group">
                                            <input type="text" id="code" name="countryCode"
                                                class="text-countryCode form-control" readonly
                                                value="<?php echo e(old('countryCode', isset($userInfo->countryCode) ? $userInfo->countryCode : '')); ?>" />
                                            
                                            
                                            <input type="text" class="form-control" name="mobile_no"
                                                placeholder="Mobile number"
                                                value="<?php echo e(old('mobile_no', isset($userInfo->mobile_no) ? $userInfo->mobile_no : '')); ?>" />
                                            <br />
                                            <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <span id="mobile_status" style="color:red; font-size:14px"></span>
                                        </div>

                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="exampleInputEmail"><b>Email-ID
                                                </b>&nbsp;<span style="color:red;">*</span></label>
                                            <input type="email" name="email" class="form-control" id="exampleInputEmail"
                                                value="<?php echo e(old('email', $userInfo->email)); ?>" placeholder="Enter email"
                                                readonly />
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="ethnicity"><b>Ethnicity</b>&nbsp;<span
                                                    style="color:red;">*</span></label>
                                                    <select name="ethnicity"  class="form-control" id="ethnicity">
                                                        <option selected >Please Select</option>
                                                        <?php if(isset($states)): ?>
                                                           <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                           <option value="<?php echo e($item->value); ?>"
                                                              <?php if(isset($userProfile) && $userProfile->ethnicity ==$item->value): ?> 
                                                                 selected
                                                                 <?php endif; ?>
                                                                >
                                                             <?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                            <?php $__errorArgs = ['ethnicity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="gender"><b>Gender
                                                </b>&nbsp;<span style="color:red;">*</span></label>
                                            <select name="gender" class="form-control" id="">
                                                <option value="">Please Select</option>
                                                <option value="male"
                                                    <?php if(isset($userProfile) && $userProfile->gender == 'male'): ?> selected 
                                                      <?php elseif(isset($userProfile) && $userProfile->gender == 'male'): ?>
                                                     
                                                      selected <?php endif; ?>>
                                                    Male</option>
                                                <option value="female"
                                                    <?php if(isset($userProfile) && $userProfile->gender == 'female'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->gender == 'female'): ?>
                                                
                                                 selected <?php endif; ?>>
                                                    Female
                                                </option>
                                                <option value="prefernottosay"
                                                    <?php if(isset($userProfile) && $userProfile->gender == 'prefernottosay'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->gender == 'prefernottosay'): ?>
                                                 selected <?php endif; ?>>
                                                    Prefer not to say
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="exampleDateOfBirth"><b>Date Of
                                                    Birth</b>&nbsp;<span style="color:red;">*</span></label>
                                            <?php if(isset($userProfile->date_of_birth) != null): ?>
                                                <input type="date" id="date_of_birth" name="date_of_birth"
                                                    class="form-control"
                                                    value="<?php echo e(old('date_of_birth', isset($userProfile->date_of_birth) ? $userProfile->date_of_birth : '')); ?>">
                                            <?php elseif(isset($userProfile->date_of_birth) != null): ?>
                                                <input type="date" id="date_of_birth" name="date_of_birth"
                                                    class="form-control"
                                                    value="<?php echo e(old('date_of_birth', isset($userProfile->date_of_birth) ? $userProfile->date_of_birth : '')); ?>">
                                            <?php else: ?>
                                                <input type="date" id="date_of_birth" name="date_of_birth"
                                                    class="form-control" value="<?php echo e(old('date_of_birth')); ?>">
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="LocationInput"><b>Current Location
                                                </b>&nbsp;<span style="color:red;">*</span></label>
                                            <?php if(isset($userProfile->current_location) != null): ?>
                                                <input type="text" id="current_location" name="current_location"
                                                    class="form-control" placeholder="Enter a current loaction"
                                                    value="<?php echo e(old('current_location', isset($userProfile->current_location) ? $userProfile->current_location : '')); ?>">
                                            <?php elseif(isset($userProfile->current_location) != null): ?>
                                                <input type="text" id="current_location" name="current_location"
                                                    class="form-control" placeholder="Enter a current loaction"
                                                    value="<?php echo e(old('current_location', isset($userProfile->current_location) ? $userProfile->current_location : '')); ?>">
                                            <?php else: ?>
                                                <input type="text" id="current_location" name="current_location"
                                                    class="form-control" value="<?php echo e(old('current_location')); ?>"
                                                    placeholder="Enter a current loaction">
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['current_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="exampleDateOfBirth"><b>Height
                                                </b>&nbsp;<span style="color:red;">*</span></label>
                                            <?php if(isset($userProfile->height) != null): ?>
                                                <input type="text" id="height" name="height" class="form-control"
                                                    placeholder="Enter your height"
                                                    value="<?php echo e(old('height', isset($userProfile->height) ? $userProfile->height : '')); ?>">
                                            <?php elseif(isset($userProfile->current_location) != null): ?>
                                                <input type="text" id="height" name="height" class="form-control"
                                                    placeholder="Enter your height"
                                                    value="<?php echo e(old('height', isset($userProfile->height) ? $userProfile->height : '')); ?>">
                                            <?php else: ?>
                                                <input type="text" id="height" name="height"
                                                    placeholder="Enter your height" class="form-control"
                                                    value="<?php echo e(old('height')); ?>">
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="complexions"><b>Complexions
                                                </b>&nbsp;<span style="color:red;">*</span></label>
                                            <select name="complexions" class="form-control" id="">
                                                <option value="">Please Select</option>
                                                <option value="fair"
                                                    <?php if(isset($userProfile) && $userProfile->complexions == 'fair'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->complexions == 'fair'): ?>
                                                
                                                 selected <?php endif; ?>>
                                                    Fair
                                                </option>
                                                <option value="medium"
                                                    <?php if(isset($userProfile) && $userProfile->complexions == 'medium'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->complexions == 'medium'): ?>
                                                
                                                 selected <?php endif; ?>>
                                                    Medium
                                                </option>
                                                <option value="olive"
                                                    <?php if(isset($userProfile) && $userProfile->complexions == 'olive'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->complexions == 'olive'): ?>
                                                
                                                 selected <?php endif; ?>>
                                                    Olive</option>
                                                <option value="brown"
                                                    <?php if(isset($userProfile) && $userProfile->complexions == 'brown'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->complexions == 'brown'): ?>
                                                
                                                 selected <?php endif; ?>>
                                                    Brown
                                                </option>
                                                <option value="black"
                                                    <?php if(isset($userProfile) && $userProfile->complexions == 'black'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->complexions == 'black'): ?>
                                                 selected <?php endif; ?>>
                                                    Black
                                                </option>
                                                <option value="extremely &amp; fair"
                                                    <?php if(isset($userProfile) && $userProfile->complexions == 'extremely & fair'): ?> selected 
                                                 <?php elseif(isset($userProfile) && $userProfile->complexions == 'extremely & fair'): ?>
                                                
                                                 selected <?php endif; ?>>
                                                    Extremely & Fair
                                                </option>
                                            </select>

                                            <?php $__errorArgs = ['complexions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-12 col-lg-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="LocationInput"><b>Choose Language
                                                </b>&nbsp;<span style="color:red;">*</span></label>
                                            <br />

                                            <div class="hide1">
                                                <select name="choose_language" onchange="newSrc(this.value)"
                                                    class="form-control">
                                                    <option value=" ">Choose language</option>
                                                    <option value="videos/sample_video_english.mp4"
                                                        <?php if(isset($userProfile) && $userProfile->choose_language == 'videos/sample_video_english.mp4'): ?> selected 
                                                     <?php elseif(isset($userProfile) && $userProfile->choose_language == 'videos/sample_video_english.mp4'): ?>
                                                   
                                                     selected <?php endif; ?>>
                                                        Intro in English

                                                    </option>
                                                    <option value="videos/sample_video_hindi.mp4"
                                                        <?php if(isset($userProfile) && $userProfile->choose_language == 'videos/sample_video_hindi.mp4'): ?> selected 
                                                     <?php elseif(isset($userProfile) && $userProfile->choose_language == 'videos/sample_video_hindi.mp4'): ?>
                                                  
                                                     selected <?php endif; ?>>
                                                        Intro in Hindi
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['choose_language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>


                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-lg-12 col-sm-12">
                                        <div class="form-group">
                                            <label class="form-label text-secondary text-gradient"
                                                for="intro_video_link"><b>Youtube Video Link
                                                </b>&nbsp;<span style="color:red;">*</span></label>

                                            <?php if(isset($userProfile->intro_video_link) != null): ?>
                                                <input type="text" id="intro_video_link" name="intro_video_link"
                                                    class="form-control" placeholder="Enter intro video link"
                                                    value="<?php echo e(old('intro_video_link', isset($userProfile->intro_video_link) ? $userProfile->intro_video_link : '')); ?>">
                                            <?php elseif(isset($userProfile->intro_video_link) != null): ?>
                                                <input type="text" id="intro_video_link" name="intro_video_link"
                                                    class="form-control" placeholder="Enter intro video link"
                                                    value="<?php echo e(old('intro_video_link', isset($userProfile->intro_video_link) ? $userProfile->intro_video_link : '')); ?>">
                                            <?php else: ?>
                                                <input type="text" id="intro_video_link" name="intro_video_link"
                                                    class="form-control" placeholder="Enter intro video link"
                                                    value="<?php echo e(old('intro_video_link')); ?>">
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['intro_video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span style="color:red;"><b><?php echo e($message); ?></b></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <br />
                                
                                <center>
                                    <br />
                                    <?php if($submitButton == 'Submit'): ?>
                                        <button type="submit" style="background:red;" class="btn btn-danger"
                                            id="btnPlay"><?php echo e($submitButton); ?></button>
                                    <?php elseif($submitButton == 'Update'): ?>
                                        <button type="submit" class="btn btn-success"
                                            id="btnPlay"><?php echo e($submitButton); ?></button>
                                    <?php endif; ?>

                                </center>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('submit-profile.right-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        var images = <?php echo json_encode($userInfo?->images?->pluck('image')?->toArray(), 15, 512) ?>;
    </script>
    
    
    <script src="<?php echo e(asset('assets/website/js/submit-profile/submit-profile.js')); ?>"></script>
    <script async defer src="<?php echo e(asset('assets/website/js/submit-profile/image-gallery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/submit-profile/workreel-video-gallery.js')); ?>"></script>
    <script>
        $('#SubmitMessage').on('click', function(e) {
            $('.input-hide').hide();

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.submit-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting\resources\views/submit-profile/create-edit.blade.php ENDPATH**/ ?>