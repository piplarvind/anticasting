<?php $__env->startSection('title'); ?>
    Submit Profile
<?php $__env->stopSection(); ?>
<style>
    .headshot_img:hover {
        color: #424242;
        -webkit-transition: all .3s ease-in;
        -moz-transition: all .3s ease-in;
        -ms-transition: all .3s ease-in;
        -o-transition: all .3s ease-in;
        transition: all .3s ease-in;
        opacity: 1;
        transform: scale(3);
        -ms-transform: scale(3);
        /* IE 9 */
        -webkit-transform: scale(3);
        /* Safari and Chrome */
    }
/* 
    tr:hover {
        background: dimgray;
        cursor: pointer;
    }

    tr.header {
        background-color: #f1f1f1;
    } */
</style>
<?php $__env->startSection('content'); ?>
    <div class="main">

        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 p-r-0 title-margin-right">
                    <div class="page-header">
                        <div class="page-title">
                            <h1>Submit Profile</h1>

                        </div>

                    </div>

                </div>

                <div class="col-lg-6 p-l-0 title-margin-left">
                    <div class="page-header">
                        <div class="page-title">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Submit Profile</li>
                            </ol>
                        </div>
                    </div>
                </div>

            </div> 
            <!-- /# row --> 
            
        <div class="row">
            <?php if(isset($items)): ?>
              <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-6">
                <div class="card support-bar overflow-hidden w-50">
                    <div class="card-body pb-0">
                        <img src="<?php echo e($item?->profileImage?->image); ?>" alt="" border="3" height="200" width='217'>
    
                    </div>
                    <div class="card-footer border-0 mt-2">
                        <div class="row text-center">
                            <h6 class="text-success">
                                <?php echo e($item->user->first_name." ".$item->user->last_name); ?>

                            </h6>
                            <div class="col">
                            </div>
                            <div class="col">
                                <h4 class="m-0">251</h4>
                                <span>June</span>
                            </div>
                            <div class="col">
                                <div class="image-info">

                                    <a href="#" title="Sample Headshot Image" ata-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="Top popover"><i
                                        class="fa fa-info-circle" aria-hidden="true"></i>
                                    </a>
                                </div>
                                <div id="popover-content" class="d-none">
                                    <div class="form-group">
                                        
                                        <div id="" class="yt-video">
                                            <img width="250"
                                                src="https://t4.ftcdn.net/jpg/02/86/91/07/360_F_286910763_zOX9bUhDQPUvk45vWOaNsGAvDf18oSod.jpg"
                                                border="1">
                            
                                        </div>
                                        <strong class="form-label">Sample resolutions</strong>
                                        <ul>
                                            <li>width: 250px</li> 
                                            <li>height: 167px</li> 
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="support-chart1"></div>
                </div>
            </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
           
        </div>
     
        </div>
    </div>
    <script src="<?php echo e(asset('assets/website/backend/submitprofile/js/index.js')); ?>"></script>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\anticasting\app\Modules/SubmitProfile/resources/views/index.blade.php ENDPATH**/ ?>