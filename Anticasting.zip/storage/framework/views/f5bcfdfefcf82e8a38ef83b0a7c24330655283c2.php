<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Anticasting <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('header'); ?>
</head>

<body style="background-color:white;">
    <!-- ======= Header ======= -->
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ======= End Header ======= -->
    <!-- ======= Hero ======= -->
    <?php echo $__env->make('include.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ======= End Hero ======= -->

    <!-- ======= Footer ======= -->
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('assets/auth/jquery-3.6.0.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/auth/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/users/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/users/assets/vendor/purecounter/purecounter_vanilla.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/users/assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/users/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/users/assets/vendor/aos/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/users/assets/vendor/php-email-form/validate.js')); ?>"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('assets/users/assets/js/main.js')); ?>"></script>
    <?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
<?php /**PATH F:\wamp64\www\anticasting\resources\views/layouts/submit-profile.blade.php ENDPATH**/ ?>