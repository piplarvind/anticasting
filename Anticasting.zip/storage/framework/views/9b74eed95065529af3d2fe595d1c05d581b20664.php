<div class="breadcrumbs">
  <div class="page-header d-flex align-items-center" style="background-image: url('<?php echo e(asset('assets/website/images/page-banner.png')); ?>');">
    <div class="container position-relative">
      <div class="row d-flex justify-content-center">
        <div class="col-lg-6 text-center">
          <h2>Submit Profile</h2>
          <p>Explore your profile</p>
        </div>
      </div>
    </div>
  </div>
  
</div><?php /**PATH F:\wamp64\www\anticasting\resources\views/include/hero.blade.php ENDPATH**/ ?>