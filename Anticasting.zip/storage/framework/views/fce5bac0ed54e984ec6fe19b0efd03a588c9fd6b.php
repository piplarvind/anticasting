<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
    <div class="nano">
        <div class="nano-content">
            <ul>
                <div class="logo">
                    <a href="<?php echo e(url('/')); ?>">
                        <!-- <img src="images/logo.png" alt="" /> --><span>Anticasting</span>
                    </a>
                </div>
                
                
                <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="ti-home"></i> Dashboard </a></li>
                <li><a href="<?php echo e(route('admin.settings')); ?>"><i class="ti-settings"></i> Settings </a></li>
                
                
                
                
                <li><a href="<?php echo e(route('admin.message')); ?>"><i class="ti-user"></i>Message</a></li>
                <li><a href="<?php echo e(route('admin.manageuser')); ?>"><i class="ti-user"></i>Manage User</a></li>
                
                <li><a href="<?php echo e(route('admin.submitprofile')); ?>"><i class="ti-user"></i>Submit Profile</a></li>
                <li><a href="<?php echo e(route('admin.changePassword')); ?>"><i class="ti-user"></i> Change Password</a></li>
                <li><a href="<?php echo e(route('admin.logout')); ?> "><i class="ti-close"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH F:\wamp64\www\anticasting\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>