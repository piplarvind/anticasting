<form method="get">
    <div class="row">
     <div class="col-md-2">
        <label  for="staticName" class="col-form-label">
            <b>Gender</b>
        </label>
                
             <select name="gender" class="form-control" id="">
                <option value="">--select--</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="Prefer not to say">Prefer not to say</option>
            </select>

        </div>
        <div class="col-md-3">
         <label for="status" class="col-form-label"><b>Ethnicity</b></label>
            
            <select name="ethnicity" class="form-control w-75" id="">
                <option value="">--select--</option>
                <?php if(isset($state)): ?>
                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->value); ?>">
                            <?php echo e($item->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="col-md-3">
            <br />
            <label for="status" class="col-form-label"><br /></label>
                <input type="submit" value="Filter" class="btn btn-primary" id="filter">
                <a href="<?php echo e(route('admin.submitprofile')); ?>" class="btn btn-danger">Reset</a>
        </div>
    </div>
</form><?php /**PATH F:\wamp64\www\anticasting\app\Modules/SubmitProfile/resources/views/profile-filter.blade.php ENDPATH**/ ?>