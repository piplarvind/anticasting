<?php

namespace App\Modules\SubmitProfile\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubmitProfile extends Model
{
    use HasFactory;

}
