<?php

return [
    'welcome' => 'Welcome, this is SubmitProfile module.'
];
