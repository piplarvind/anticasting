<?php

return [
    'welcome' => 'Welcome, this is Users module.'
];
