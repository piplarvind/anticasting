<?php

return [
    'welcome' => 'Welcome, this is Actors module.'
];
