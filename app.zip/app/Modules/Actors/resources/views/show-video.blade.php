<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-center">
            <h3 class="h4 text-bg-secondary">Introduction Video(s)</h3>
        </div>
        <div id="video-section" class="mb-2">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                         <div class="col-md-6">
                            <span class="font-color h5 d-flex justify-content-center">Hindi</span>
                            @if (isset($actor?->introVideo)&& $actor?->introVideo != null)
                             <iframe class="video" style="width:100%;" src="{{$actor?->introVideo?->hindi_video}}" allowfullscreen="true">
                             </iframe>
                             @else
                              <img src="{{ asset('assets/images/yt-thumbnail.png') }}" alt="" width="200" height="200"/>
                              {{-- <br/>
                              <br/>
                              <span class="no-video fw-bold">No Video</span> --}}
                            @endif
                         </div>
                         <div class="col-md-6">
                            <span class="font-color h5 d-flex justify-content-center">English</span>
                            @if (isset($actor?->introVideo)&& $actor?->introVideo != null)
                             <iframe class="video" style="width:100%;" src="{{$actor?->introVideo?->english_video}}" allowfullscreen="true">
                             </iframe>
                             @else
                             <img src="{{ asset('assets/images/yt-thumbnail.png') }}" alt="" width="200" height="200" />
                             {{-- <br/>
                              <br/>
                             <span class="no-video fw-bold">No Video</span> --}}
                            @endif
                         </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6">
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('#english_video').hide();
    $('#hindi').on('click', function() {
        $('#english_video').hide();
        $('#hindi_video').show();
    })
    $('#english').on('click', function() {
        $('#hindi_video').hide();
        $('#english_video').show();
    })

    function stopVideo(element) {
        // getting every iframe from the body
        var iframes = element.querySelectorAll('iframe');
        // reinitializing the values of the src attribute of every iframe to stop the YouTube video.
        for (let i = 0; i < iframes.length; i++) {
            if (iframes[i] !== null) {
                var temp = iframes[i].src;
                iframes[i].src = temp;
            }
        }
    };
</script>
