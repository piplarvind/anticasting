<!DOCTYPE html>
<html>
<head>
    <title>Forgot password send email</title>
</head>
<body>
    <h6><?php echo e($token); ?></h6>
    <a href="<?php echo e(route('users.reset-password',['token'=>$token,'email'=>$email])); ?>">Reset link</a>
</body>
</html><?php /**PATH F:\wamp64\www\anticasting\resources\views/emails/forget-password.blade.php ENDPATH**/ ?>