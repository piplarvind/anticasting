<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reset Link</title>
</head>
<body>
   <h6><?php echo e($token); ?></h6>
   <h6><?php echo e($email); ?></h6>

   <div>
    <a href="<?php echo e(route('admin.reset-password',['token'=>$token,'email'=>$email])); ?>">RESEND LINK</a>
   </div>
 
</body>
</html><?php /**PATH F:\wamp64\www\anticasting\resources\views/admin/emails/forget-password.blade.php ENDPATH**/ ?>