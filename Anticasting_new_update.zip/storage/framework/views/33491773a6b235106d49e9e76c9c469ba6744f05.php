<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Anticasting | ForgotPassword</title>
        <link href="<?php echo e(asset('assets/auth/css/styles.css')); ?>" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('assets/auth/jquery-3.6.0.js')); ?>"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/auth/toastr.min.css')); ?>">
        <script src="<?php echo e(asset('assets/auth/toastr.min.js')); ?>"></script>
    </head>
    <body >
        <br/>
        <br/>
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
             
              <script>
                 <?php if(Session::has('message')): ?>
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                    <?php elseif(Session::has('error')): ?>
                      toastr.error("<?php echo e(Session::get('error')); ?>");
                  <?php endif; ?>
              </script>
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                     <div class="card-body">
                                         <div class="border-0">
                                               <span class="lead text-muted" >
                                                  Please enter your  email address. You will receive an email message with instructions on how to reset your password.
                                               </span>
                                         </div>
                                    </div>
                                  
                                </div>
                                <div class="card shadow-lg border-0 rounded-lg mt-3">
                                  
                                    <div class="card-body">
                                        <form action="<?php echo e(route('users.forgotpassword-post')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form mb-3">
                                                <label for="email" class="text-muted" >Email Address</label>
                                                <br/>
                                                <input class="form-control" id="Email" name="email" type="email" placeholder="Enter a email" />
                                               
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <span class="text-danger"><b><?php echo e($message); ?></b></span>  
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                           
                                           
                                           <div  style="margin-left:280px;" class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                               
                                            <button type="submit" class="btn-sm btn btn-primary active">Get New Password</button>
                                            </div>
                                        </form>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
           
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('assets/auth/js/scripts.js')); ?>"></script>
    </body>
</html>
<?php /**PATH F:\wamp64\www\anticasting\resources\views/auth/forgotpassword.blade.php ENDPATH**/ ?>