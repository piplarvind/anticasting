<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Anticasting | Profile</title>

    <!-- font css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/submitprofile/fonts/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/submitprofile/fonts/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/submitprofile/fonts/material.css')); ?>">
    <script src="<?php echo e(asset('assets/auth/jquery-3.6.0.js')); ?>"></script>
    <!-- vendor css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/submitprofile/css/style.css')); ?>" id="main-style-link">
</head>


<body>

     <?php echo $__env->yieldContent('profileContent'); ?>
     
    <script src="<?php echo e(asset('assets/submitprofile/js/vendor-all.min.js')); ?>"></script>
    <script src="assets/submitprofile/js/plugins/bootstrap.min.js"></script>
    <script src="assets/submitprofile/js/plugins/feather.min.js"></script>
    <script src="assets/submitprofile/js/pcoded.min.js"></script>
</body>

</html>
<?php /**PATH F:\wamp64\www\anticasting\resources\views/layouts/submit_profile_layouts.blade.php ENDPATH**/ ?>