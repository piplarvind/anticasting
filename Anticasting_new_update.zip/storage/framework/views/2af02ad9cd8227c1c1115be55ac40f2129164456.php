<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="<?php echo e(asset('assets/auth/jquery-3.6.0.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/auth/toastr.min.css')); ?>">
    <script src="<?php echo e(asset('assets/auth/toastr.min.js')); ?>"></script>
</head>
<body>
    <script>
        <?php if(Session::has('message')): ?>
           toastr.success("<?php echo e(Session::get('message')); ?>");
         <?php endif; ?>
     </script>
    <h1>Home</h1>
   
    <a href="<?php echo e(route('users.change-password')); ?>">ChangePassword</a>
    <a href="<?php echo e(route('users.submitProfile')); ?>">SubmitProfile</a>
    <a href="<?php echo e(route('users.logout')); ?>">Logout</a>
</body>
</html><?php /**PATH F:\wamp64\www\anticasting\resources\views/home.blade.php ENDPATH**/ ?>