<?php

use Illuminate\Support\Facades\Route;

Route::get('users', 'UsersController@welcome');
