<link
rel="shortcut icon"
type="image/x-icon"
href="{{ asset('assets/submitprofile/assets/images/favicon.svg') }}"
/>
<link
href="https://fonts.googleapis.com/css2?family=Spartan:wght@100;200;300;400;500;600;700;800;900&display=swap"
rel="stylesheet"
/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
/>
<link rel="stylesheet" href="{{ asset('assets/submitprofile/assets/css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/submitprofile/assets/css/style.css') }}" />
<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

