<div class="page-banner">
    <div class="breadcrumbs">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 offset-lg-2 col-12">
            <div class="breadcrumbs-content">
              <h1 class="page-title">Talent Submission Form</h1>
            </div>
            <ul class="breadcrumb-nav">
              <li>
                <a href="{{ route('users.home') }}">Home</a>
              </li>
              <li>Service Details</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>